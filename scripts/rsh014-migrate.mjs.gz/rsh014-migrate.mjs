#!/usr/bin/env node
import { createHash } from "node:crypto";
import {
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { basename, dirname, join, relative, resolve } from "node:path";
import ts from "typescript";

const ROOT = process.cwd();
const BASE_SHA = "0273520da4924cb3e71ff41b2ea75788a45bf757";
const BASE_TREE = "986917098fa8ca09f9f1db4cf10a0e2dd32a33e8";
const RSH013_PR_HEAD = "e5a0787ce0c706beef10fa1cc5acf2445a6ea933";
const RSH013_LEGACY_BLOB = "e26454223f8a598cdf516af7c7c3f494162e2616";
const RSH013_RUNTIME_DIGEST = "a1ccf6f71ca7c4bad7fbc1280aecb04cdc4390ca400cf183cd3fde916d14294d";
const RSH013_AGGREGATE_DIGEST = "1f10ef1b656fb61b414aed82a1918ade65c5093fcedf486b2aa3b37527d5dfb7";
const RSH013_MATH_BLOB = "c215daef16056d5d7c142db964ed93f82c74f8e8";
const RSH013_TYPES_BLOB = "f2ce095b2fcd4f9fa6f55ce0c3413ffa8d09d6c0";
const RSH013_WORLD_BLOB = "07b7e0b559e66f89641357db5aa2be8bcd8c3135";
const SHARED_MARKER = "// RSH-014: GENERATED EXPORT BRIDGE — excluded from the reconstructed RSH-013 source\n";
const FACADE_MARKER = "// RSH-014: RECONSTRUCTED LEGACY POSTLUDE START\n";

function abs(...parts) {
  return join(ROOT, ...parts);
}
function read(path) {
  return readFileSync(abs(path), "utf8");
}
function write(path, content) {
  const target = abs(path);
  mkdirSync(dirname(target), { recursive: true });
  writeFileSync(target, content, "utf8");
}
function writeJson(path, value) {
  write(path, JSON.stringify(value, null, 2) + "\n");
}
function sha256(value) {
  return createHash("sha256").update(String(value), "utf8").digest("hex");
}
function gitBlobSha1(value) {
  const body = Buffer.from(String(value), "utf8");
  return createHash("sha1")
    .update(Buffer.from(`blob ${body.length}\0`, "utf8"))
    .update(body)
    .digest("hex");
}
function invariant(condition, message) {
  if (!condition) throw new Error(message);
}
function hasExportModifier(node) {
  return Boolean(node.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.ExportKeyword));
}
function localNameFromModuleId(id, index) {
  const safe = id.replace(/[^a-zA-Z0-9_$]/g, "_");
  return `track_${String(index + 1).padStart(2, "0")}_${safe}`;
}
function propertyName(name) {
  if (ts.isIdentifier(name) || ts.isStringLiteral(name) || ts.isNumericLiteral(name)) {
    return name.text;
  }
  return null;
}
function identifierNames(node) {
  const names = new Set();
  const visit = (current) => {
    if (ts.isIdentifier(current)) names.add(current.text);
    ts.forEachChild(current, visit);
  };
  visit(node);
  return names;
}
function parseTypeScript(fileName, source) {
  const file = ts.createSourceFile(fileName, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  invariant(file.parseDiagnostics.length === 0, `${fileName} has parse diagnostics before migration`);
  return file;
}
function findTracksStatement(file) {
  for (const statement of file.statements) {
    if (!ts.isVariableStatement(statement)) continue;
    for (const declaration of statement.declarationList.declarations) {
      if (ts.isIdentifier(declaration.name) && declaration.name.text === "TRACKS") {
        return { statement, declaration };
      }
    }
  }
  throw new Error("TRACKS variable statement not found");
}
function unwrap(node) {
  let current = node;
  while (
    current
    && (ts.isParenthesizedExpression(current)
      || ts.isAsExpression(current)
      || ts.isSatisfiesExpression(current)
      || ts.isNonNullExpression(current))
  ) {
    current = current.expression;
  }
  return current;
}
function findTrackArray(declaration) {
  invariant(declaration.initializer, "TRACKS has no initializer");
  const initializer = unwrap(declaration.initializer);
  if (ts.isArrayLiteralExpression(initializer)) return initializer;
  if (ts.isCallExpression(initializer) && initializer.arguments.length === 1) {
    const argument = unwrap(initializer.arguments[0]);
    if (ts.isArrayLiteralExpression(argument)) return argument;
  }
  throw new Error("TRACKS initializer is not an array literal");
}
function extractTrackId(object, file) {
  for (const property of object.properties) {
    if (!ts.isPropertyAssignment(property)) continue;
    if (propertyName(property.name) !== "id") continue;
    const value = unwrap(property.initializer);
    if (ts.isStringLiteral(value) || ts.isNoSubstitutionTemplateLiteral(value)) return value.text;
  }
  throw new Error(`Track object at ${object.getStart(file)} has no string id`);
}
function topLevelValueAuthority(file, cutoff) {
  const names = new Set();
  const exportedNames = new Set();
  const runtimeImportNames = new Set();
  const localDeclarationNames = new Set();

  for (const statement of file.statements) {
    if (statement.getStart(file) >= cutoff) break;
    if (ts.isImportDeclaration(statement)) {
      const clause = statement.importClause;
      if (!clause || clause.isTypeOnly) continue;
      if (clause.name) {
        names.add(clause.name.text);
        runtimeImportNames.add(clause.name.text);
      }
      if (clause.namedBindings && ts.isNamedImports(clause.namedBindings)) {
        for (const element of clause.namedBindings.elements) {
          if (element.isTypeOnly) continue;
          names.add(element.name.text);
          runtimeImportNames.add(element.name.text);
        }
      }
      if (clause.namedBindings && ts.isNamespaceImport(clause.namedBindings)) {
        names.add(clause.namedBindings.name.text);
        runtimeImportNames.add(clause.namedBindings.name.text);
      }
      continue;
    }

    const exported = hasExportModifier(statement);
    if (ts.isFunctionDeclaration(statement) || ts.isClassDeclaration(statement)) {
      if (statement.name) {
        names.add(statement.name.text);
        localDeclarationNames.add(statement.name.text);
        if (exported) exportedNames.add(statement.name.text);
      }
      continue;
    }
    if (ts.isVariableStatement(statement)) {
      for (const declaration of statement.declarationList.declarations) {
        if (!ts.isIdentifier(declaration.name)) continue;
        names.add(declaration.name.text);
        localDeclarationNames.add(declaration.name.text);
        if (exported) exportedNames.add(declaration.name.text);
      }
    }
  }
  return { names, exportedNames, runtimeImportNames, localDeclarationNames };
}
function originalImportBlock(file, source, cutoff) {
  const imports = file.statements.filter(
    (statement) => ts.isImportDeclaration(statement) && statement.getStart(file) < cutoff,
  );
  if (!imports.length) return "";
  const end = imports.at(-1).end;
  return source.slice(0, end) + "\n";
}
function normalizeSharedForLegacy(source) {
  const marker = source.indexOf(SHARED_MARKER);
  invariant(marker >= 0, "shared source is missing the generated export marker");
  return source.slice(0, marker)
    .replaceAll('"../math"', '"./math"')
    .replaceAll('"../types"', '"./types"');
}
function extractObjectFromModule(source, path) {
  const file = parseTypeScript(path, source);
  const exportAssignment = file.statements.find((statement) => ts.isExportAssignment(statement));
  invariant(exportAssignment && !exportAssignment.isExportEquals, `${path} must have one default export`);
  const call = unwrap(exportAssignment.expression);
  invariant(ts.isCallExpression(call), `${path} default export must call defineTrack`);
  invariant(ts.isIdentifier(call.expression) && call.expression.text === "defineTrack", `${path} must call defineTrack`);
  invariant(call.arguments.length === 1, `${path} defineTrack must receive one object`);
  const object = unwrap(call.arguments[0]);
  invariant(ts.isObjectLiteralExpression(object), `${path} defineTrack argument must be an object literal`);
  return source.slice(object.getStart(file), object.end);
}
function reconstructLegacySource(manifest, sharedSource, facadeSource, moduleSources) {
  const sharedLegacy = normalizeSharedForLegacy(sharedSource);
  const marker = facadeSource.indexOf(FACADE_MARKER);
  invariant(marker >= 0, "facade is missing the postlude marker");
  const postlude = facadeSource.slice(marker + FACADE_MARKER.length);
  const objects = manifest.modules.map((entry) => extractObjectFromModule(moduleSources[entry.path], entry.path));
  const layout = manifest.legacy_reconstruction.layout;
  invariant(layout.separators.length === objects.length - 1, "legacy separator count is incorrect");
  let statement = layout.statement_prefix + layout.leading;
  for (let index = 0; index < objects.length; index += 1) {
    statement += objects[index];
    if (index < layout.separators.length) statement += layout.separators[index];
  }
  statement += layout.trailing + layout.statement_suffix;
  return sharedLegacy + statement + postlude;
}
function listFilesRecursive(rootDir) {
  const output = [];
  if (!existsSync(rootDir)) return output;
  for (const name of readdirSync(rootDir)) {
    const path = join(rootDir, name);
    const stat = statSync(path);
    if (stat.isDirectory()) output.push(...listFilesRecursive(path));
    else output.push(path);
  }
  return output;
}
function patchCanonicalTrackReads() {
  const scriptsDir = abs("scripts");
  const files = listFilesRecursive(scriptsDir).filter((path) => path.endsWith(".mjs"));
  const exact = /readFileSync\(fromRoot\("src",\s*"game",\s*"tracks\.ts"\),\s*"utf8"\)/g;
  for (const path of files) {
    const rel = relative(ROOT, path).replaceAll("\\", "/");
    if ([
      "scripts/rsh014-migrate.mjs",
      "scripts/load-track-modules.mjs",
      "scripts/check-track-schema.mjs",
      "scripts/check-track-module-manifest.mjs",
      "scripts/check-track-module-manifest.test.mjs",
      "scripts/check-track-source-pin.test.mjs",
    ].includes(rel)) continue;
    let source = readFileSync(path, "utf8");
    if (!exact.test(source)) {
      exact.lastIndex = 0;
      continue;
    }
    exact.lastIndex = 0;
    source = source.replace(exact, "readCanonicalTrackSource()");
    if (!source.includes('from "./load-track-modules.mjs"')) {
      const parsed = ts.createSourceFile(rel, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
      const imports = parsed.statements.filter((statement) => ts.isImportDeclaration(statement));
      const insertAt = imports.length
        ? imports.at(-1).end
        : source.startsWith("#!")
          ? source.indexOf("\n") + 1
          : 0;
      source = source.slice(0, insertAt)
        + '\nimport { readCanonicalTrackSource } from "./load-track-modules.mjs";'
        + source.slice(insertAt);
    }
    writeFileSync(path, source, "utf8");
  }
}

const original = read("src/game/tracks.ts");
invariant(gitBlobSha1(original) === RSH013_LEGACY_BLOB, "live tracks.ts does not match the accepted RSH-013 blob");
const file = parseTypeScript("src/game/tracks.ts", original);
const { statement: tracksStatement, declaration: tracksDeclaration } = findTracksStatement(file);
const trackArray = findTrackArray(tracksDeclaration);
invariant(trackArray.elements.length === 56, `expected 56 tracks, got ${trackArray.elements.length}`);
const objects = trackArray.elements.map((element) => unwrap(element));
invariant(objects.every((object) => ts.isObjectLiteralExpression(object)), "all TRACKS entries must be object literals");
const ids = objects.map((object) => extractTrackId(object, file));
invariant(new Set(ids).size === 56, "track IDs are not unique");

const statementStart = tracksStatement.getStart(file);
const arrayStart = trackArray.getStart(file);
const arrayEnd = trackArray.end;
const pre = original.slice(0, statementStart);
const post = original.slice(tracksStatement.end);
const valueAuthority = topLevelValueAuthority(file, statementStart);
const moduleExportNames = [...valueAuthority.names].sort();
const bridgeNames = moduleExportNames.filter((name) => !valueAuthority.exportedNames.has(name));
const sharedSource = pre
  .replaceAll('"./math"', '"../math"')
  .replaceAll('"./types"', '"../types"')
  + SHARED_MARKER
  + (bridgeNames.length ? `export { ${bridgeNames.join(", ")} };\n` : "");

const postFile = parseTypeScript("postlude.ts", originalImportBlock(file, original, statementStart) + post);
const postIdentifiers = identifierNames(postFile);
const postSharedImports = [...valueAuthority.localDeclarationNames]
  .filter((name) => postIdentifiers.has(name))
  .sort();
const publicSharedExports = [...valueAuthority.exportedNames].sort();

const facadeParts = [originalImportBlock(file, original, statementStart).trimEnd()];
facadeParts.push('import { TRACKS } from "./tracks/index";');
if (postSharedImports.length) {
  facadeParts.push(`import { ${postSharedImports.join(", ")} } from "./tracks/shared";`);
}
facadeParts.push("", "export { TRACKS };");
if (publicSharedExports.length) {
  facadeParts.push(`export { ${publicSharedExports.join(", ")} } from "./tracks/shared";`);
}
facadeParts.push("", FACADE_MARKER.trimEnd());
const facadeSource = facadeParts.join("\n") + post;

rmSync(abs("src/game/tracks"), { recursive: true, force: true });
mkdirSync(abs("src/game/tracks"), { recursive: true });
write("src/game/tracks/shared.ts", sharedSource);
write("src/game/tracks.ts", facadeSource);

const moduleRecords = [];
const moduleSources = {};
for (let index = 0; index < objects.length; index += 1) {
  const object = objects[index];
  const id = ids[index];
  const path = `src/game/tracks/${id}.ts`;
  const used = [...identifierNames(object)].filter((name) => valueAuthority.names.has(name)).sort();
  const parts = ['import { defineTrack } from "../track-schema";'];
  if (used.length) parts.push(`import { ${used.join(", ")} } from "./shared";`);
  const objectText = original.slice(object.getStart(file), object.end);
  parts.push("", `export default defineTrack(${objectText});`, "");
  const source = parts.join("\n");
  write(path, source);
  moduleSources[path] = source;
  moduleRecords.push({
    ordinal: index + 1,
    id,
    path,
    local_binding: localNameFromModuleId(id, index),
    git_blob_sha1: gitBlobSha1(source),
    sha256: sha256(source),
    object_ast_sha256: null,
  });
}

const indexLines = [
  'import { defineTracks } from "../track-schema";',
  'import type { TrackDef } from "../types";',
];
for (const entry of moduleRecords) {
  indexLines.push(`import ${entry.local_binding} from "./${entry.id}";`);
}
indexLines.push(
  "",
  "export const TRACKS: TrackDef[] = defineTracks<TrackDef[]>([",
  ...moduleRecords.map((entry) => `  ${entry.local_binding},`),
  "]);",
  "",
);
const indexSource = indexLines.join("\n");
write("src/game/tracks/index.ts", indexSource);

const layout = {
  statement_prefix: original.slice(statementStart, arrayStart + 1),
  leading: original.slice(arrayStart + 1, objects[0].getStart(file)),
  separators: objects.slice(0, -1).map((object, index) =>
    original.slice(object.end, objects[index + 1].getStart(file))),
  trailing: original.slice(objects.at(-1).end, arrayEnd - 1),
  statement_suffix: original.slice(arrayEnd - 1, tracksStatement.end),
};

const manifest = {
  schema_version: "1.0.0",
  document_type: "rush-track-module-manifest",
  unit: "RSH-014",
  repository: "talstilkol/rush-israel",
  canonical_branch: "main",
  implementation_base: {
    commit_sha: BASE_SHA,
    tree_sha: BASE_TREE,
    rsh_013_validated_head_sha: RSH013_PR_HEAD,
    rsh_013_legacy_tracks_git_blob_sha1: RSH013_LEGACY_BLOB,
  },
  layout: {
    state: "modular",
    facade_path: "src/game/tracks.ts",
    shared_path: "src/game/tracks/shared.ts",
    index_path: "src/game/tracks/index.ts",
    module_directory: "src/game/tracks",
    module_extension: ".ts",
    module_count: 56,
    one_module_per_track: true,
    module_export: "default_defineTrack",
    catalogue_constructor: "defineTracks",
  },
  counts: { total: 56, mvp: 8, deferred: 48 },
  runtime_order: ids,
  modules: moduleRecords,
  source_identities: {
    facade: {
      path: "src/game/tracks.ts",
      git_blob_sha1: gitBlobSha1(facadeSource),
      sha256: sha256(facadeSource),
    },
    shared: {
      path: "src/game/tracks/shared.ts",
      git_blob_sha1: gitBlobSha1(sharedSource),
      sha256: sha256(sharedSource),
    },
    index: {
      path: "src/game/tracks/index.ts",
      git_blob_sha1: gitBlobSha1(indexSource),
      sha256: sha256(indexSource),
    },
    type_authority: {
      path: "src/game/types.ts",
      git_blob_sha1: RSH013_TYPES_BLOB,
    },
    math_support: {
      path: "src/game/math.ts",
      git_blob_sha1: RSH013_MATH_BLOB,
    },
    world_consumer: {
      path: "src/game/world.ts",
      git_blob_sha1: RSH013_WORLD_BLOB,
    },
  },
  semantic_integrity: {
    ordered_runtime_definition_digest_sha256: RSH013_RUNTIME_DIGEST,
    aggregate_runtime_definition_digest_sha256: RSH013_AGGREGATE_DIGEST,
    runtime_data_changes: 0,
    runtime_order_changes: 0,
    track_id_changes: 0,
    mvp_classification_changes: 0,
    asset_changes: 0,
    dependency_changes: 0,
    release_gates_green: 0,
    release_gates_total: 13,
  },
  legacy_reconstruction: {
    purpose: "Reconstruct the exact accepted RSH-013 source from modular authorities for byte and semantic validation; no duplicate runtime catalogue is stored.",
    expected_git_blob_sha1: RSH013_LEGACY_BLOB,
    expected_sha256: sha256(original),
    layout,
  },
  change_control: {
    module_changes_require_owner_authorization: true,
    runtime_data_changes_require_owner_authorization: true,
    runtime_order_changes_require_owner_authorization: true,
    track_id_changes_require_owner_authorization: true,
    mvp_mapping_changes_require_owner_authorization: true,
    "RSH-015_authorized": false,
  },
};

const reconstructed = reconstructLegacySource(manifest, sharedSource, facadeSource, moduleSources);
invariant(reconstructed === original, "modular reconstruction is not byte-identical to accepted RSH-013 tracks.ts");
invariant(gitBlobSha1(reconstructed) === RSH013_LEGACY_BLOB, "reconstructed legacy Git blob drifted");
manifest.legacy_reconstruction.actual_git_blob_sha1 = gitBlobSha1(reconstructed);
manifest.legacy_reconstruction.actual_sha256 = sha256(reconstructed);
const moduleSetPayload = moduleRecords.map((entry) => `${entry.ordinal}:${entry.id}:${entry.path}:${entry.git_blob_sha1}`).join("\n");
manifest.source_identities.module_set_sha256 = sha256(moduleSetPayload);
writeJson("TRACK-MODULE-MANIFEST.json", manifest);
const manifestSource = read("TRACK-MODULE-MANIFEST.json");
const manifestSha256 = sha256(manifestSource);

const loaderSource = `#!/usr/bin/env node
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import ts from "typescript";
import { fromRoot } from "./project-root.mjs";

export const SHARED_MARKER = ${JSON.stringify(SHARED_MARKER)};
export const FACADE_MARKER = ${JSON.stringify(FACADE_MARKER)};

export function sha256(value) {
  return createHash("sha256").update(String(value), "utf8").digest("hex");
}
export function gitBlobSha1(value) {
  const body = Buffer.from(String(value), "utf8");
  return createHash("sha1")
    .update(Buffer.from(\`blob \${body.length}\\0\`, "utf8"))
    .update(body)
    .digest("hex");
}
function parse(fileName, source) {
  const file = ts.createSourceFile(fileName, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  if (file.parseDiagnostics.length) throw new Error(\`\${fileName} has TypeScript parse diagnostics\`);
  return file;
}
function unwrap(node) {
  let current = node;
  while (current && (ts.isParenthesizedExpression(current) || ts.isAsExpression(current)
    || ts.isSatisfiesExpression(current) || ts.isNonNullExpression(current))) current = current.expression;
  return current;
}
export function extractTrackObjectSource(source, path = "track-module.ts") {
  const file = parse(path, source);
  const assignment = file.statements.find((statement) => ts.isExportAssignment(statement));
  if (!assignment || assignment.isExportEquals) throw new Error(\`\${path} must default-export defineTrack(...)\`);
  const call = unwrap(assignment.expression);
  if (!ts.isCallExpression(call) || !ts.isIdentifier(call.expression)
    || call.expression.text !== "defineTrack" || call.arguments.length !== 1) {
    throw new Error(\`\${path} must default-export defineTrack(object)\`);
  }
  const object = unwrap(call.arguments[0]);
  if (!ts.isObjectLiteralExpression(object)) throw new Error(\`\${path} defineTrack argument must be an object literal\`);
  return source.slice(object.getStart(file), object.end);
}
export function readTrackModuleManifestSource() {
  return readFileSync(fromRoot("TRACK-MODULE-MANIFEST.json"), "utf8");
}
export function readTrackModuleManifest() {
  return JSON.parse(readTrackModuleManifestSource());
}
let cache = null;
export function readTrackModuleBundle() {
  if (cache) return cache;
  const manifestSource = readTrackModuleManifestSource();
  const manifest = JSON.parse(manifestSource);
  const sharedSource = readFileSync(fromRoot(...manifest.layout.shared_path.split("/")), "utf8");
  const facadeSource = readFileSync(fromRoot(...manifest.layout.facade_path.split("/")), "utf8");
  const indexSource = readFileSync(fromRoot(...manifest.layout.index_path.split("/")), "utf8");
  const moduleSources = Object.fromEntries(manifest.modules.map((entry) => [
    entry.path,
    readFileSync(fromRoot(...entry.path.split("/")), "utf8"),
  ]));
  cache = { manifest, manifestSource, sharedSource, facadeSource, indexSource, moduleSources };
  return cache;
}
export function reconstructCanonicalTrackSource(bundle = readTrackModuleBundle()) {
  const { manifest, sharedSource, facadeSource, moduleSources } = bundle;
  const sharedMarker = sharedSource.indexOf(SHARED_MARKER);
  if (sharedMarker < 0) throw new Error("shared source export bridge marker missing");
  const sharedLegacy = sharedSource.slice(0, sharedMarker)
    .replaceAll('"../math"', '"./math"')
    .replaceAll('"../types"', '"./types"');
  const facadeMarker = facadeSource.indexOf(FACADE_MARKER);
  if (facadeMarker < 0) throw new Error("track facade postlude marker missing");
  const postlude = facadeSource.slice(facadeMarker + FACADE_MARKER.length);
  const objects = manifest.modules.map((entry) => extractTrackObjectSource(moduleSources[entry.path], entry.path));
  const layout = manifest.legacy_reconstruction.layout;
  let statement = layout.statement_prefix + layout.leading;
  objects.forEach((object, index) => {
    statement += object;
    if (index < layout.separators.length) statement += layout.separators[index];
  });
  statement += layout.trailing + layout.statement_suffix;
  return sharedLegacy + statement + postlude;
}
let canonicalSourceCache = null;
export function readCanonicalTrackSource() {
  canonicalSourceCache ??= reconstructCanonicalTrackSource();
  return canonicalSourceCache;
}
`;
write("scripts/load-track-modules.mjs", loaderSource);

const manifestValidatorSource = `#!/usr/bin/env node
import { readdirSync, readFileSync, realpathSync } from "node:fs";
import { fileURLToPath } from "node:url";
import ts from "typescript";
import { fromRoot } from "./project-root.mjs";
import {
  extractTrackObjectSource,
  gitBlobSha1,
  readCanonicalTrackSource,
  readTrackModuleBundle,
  sha256,
} from "./load-track-modules.mjs";

export const EXPECTED_MANIFEST_SHA256 = "${manifestSha256}";
export const EXPECTED_LEGACY_GIT_BLOB_SHA1 = "${RSH013_LEGACY_BLOB}";
export const EXPECTED_RUNTIME_DIGEST = "${RSH013_RUNTIME_DIGEST}";
export const EXPECTED_AGGREGATE_DIGEST = "${RSH013_AGGREGATE_DIGEST}";
export const EXPECTED_MODULE_COUNT = 56;

function parse(fileName, source, errors) {
  const file = ts.createSourceFile(fileName, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  for (const diagnostic of file.parseDiagnostics) {
    errors.push(\`\${fileName} does not parse: \${ts.flattenDiagnosticMessageText(diagnostic.messageText, " ")}\`);
  }
  return file;
}
function propertyName(name) {
  return ts.isIdentifier(name) || ts.isStringLiteral(name) ? name.text : null;
}
function trackIdFromObjectSource(source, path, errors) {
  let objectSource;
  try { objectSource = extractTrackObjectSource(source, path); }
  catch (error) { errors.push(error.message); return null; }
  const file = parse(path + "#object", \`const value = \${objectSource};\`, errors);
  const statement = file.statements[0];
  const object = statement?.declarationList?.declarations?.[0]?.initializer;
  if (!object || !ts.isObjectLiteralExpression(object)) return null;
  const idProperty = object.properties.find((property) =>
    ts.isPropertyAssignment(property) && propertyName(property.name) === "id");
  return idProperty && ts.isStringLiteral(idProperty.initializer) ? idProperty.initializer.text : null;
}
function hasCanonicalDefineTrackImport(source, path, errors) {
  const file = parse(path, source, errors);
  const imports = file.statements.filter((statement) => ts.isImportDeclaration(statement));
  const canonical = imports.filter((statement) => statement.moduleSpecifier.text === "../track-schema")
    .flatMap((statement) => statement.importClause?.namedBindings?.elements ?? [])
    .filter((element) => element.name.text === "defineTrack" && !element.propertyName);
  if (canonical.length !== 1) errors.push(\`\${path} must import canonical defineTrack exactly once\`);
  const defaults = file.statements.filter((statement) => ts.isExportAssignment(statement));
  if (defaults.length !== 1) errors.push(\`\${path} must contain exactly one default export\`);
  if (/\\bTRACKS\\b/.test(source)) errors.push(\`\${path} must contain one track only, not TRACKS\`);
}
function validateIndex(source, manifest, errors) {
  const file = parse(manifest.layout.index_path, source, errors);
  const defaultImports = new Map();
  let defineTracksImports = 0;
  for (const statement of file.statements) {
    if (!ts.isImportDeclaration(statement) || !ts.isStringLiteral(statement.moduleSpecifier)) continue;
    if (statement.moduleSpecifier.text === "../track-schema") {
      const elements = statement.importClause?.namedBindings?.elements ?? [];
      defineTracksImports += elements.filter((element) => element.name.text === "defineTracks").length;
    }
    if (statement.importClause?.name) defaultImports.set(statement.importClause.name.text, statement.moduleSpecifier.text);
  }
  if (defineTracksImports !== 1) errors.push("track index must import canonical defineTracks exactly once");
  const statement = file.statements.find((item) => ts.isVariableStatement(item)
    && item.declarationList.declarations.some((decl) => ts.isIdentifier(decl.name) && decl.name.text === "TRACKS"));
  const declaration = statement?.declarationList.declarations.find((decl) => ts.isIdentifier(decl.name) && decl.name.text === "TRACKS");
  let init = declaration?.initializer;
  if (init && ts.isAsExpression(init)) init = init.expression;
  if (!init || !ts.isCallExpression(init) || !ts.isIdentifier(init.expression) || init.expression.text !== "defineTracks") {
    errors.push("track index TRACKS must be created by defineTracks");
    return;
  }
  const array = init.arguments[0];
  if (!array || !ts.isArrayLiteralExpression(array)) {
    errors.push("track index defineTracks argument must be an array literal");
    return;
  }
  const actual = array.elements.map((element) => ts.isIdentifier(element) ? defaultImports.get(element.text) : null);
  const expected = manifest.modules.map((entry) => \`./\${entry.id}\`);
  if (JSON.stringify(actual) !== JSON.stringify(expected)) errors.push("track index runtime order differs from manifest");
}
export function validateTrackModuleManifest(input = {}) {
  const bundle = input.bundle ?? readTrackModuleBundle();
  const { manifest, manifestSource, sharedSource, facadeSource, indexSource, moduleSources } = bundle;
  const errors = [];
  if (sha256(manifestSource) !== EXPECTED_MANIFEST_SHA256) errors.push("module manifest differs from accepted RSH-014 authority");
  if (manifest.schema_version !== "1.0.0" || manifest.document_type !== "rush-track-module-manifest") {
    errors.push("module manifest identity is invalid");
  }
  if (manifest.unit !== "RSH-014" || manifest.repository !== "talstilkol/rush-israel" || manifest.canonical_branch !== "main") {
    errors.push("module manifest program authority is invalid");
  }
  if (manifest.layout?.module_count !== EXPECTED_MODULE_COUNT || manifest.modules?.length !== EXPECTED_MODULE_COUNT) {
    errors.push("module manifest must contain exactly 56 track modules");
  }
  if (manifest.counts?.total !== 56 || manifest.counts?.mvp !== 8 || manifest.counts?.deferred !== 48) {
    errors.push("module manifest counts must remain 56/8/48");
  }
  if (manifest.semantic_integrity?.ordered_runtime_definition_digest_sha256 !== EXPECTED_RUNTIME_DIGEST
    || manifest.semantic_integrity?.aggregate_runtime_definition_digest_sha256 !== EXPECTED_AGGREGATE_DIGEST) {
    errors.push("module manifest semantic digests differ from RSH-013");
  }
  const ids = manifest.modules.map((entry) => entry.id);
  if (new Set(ids).size !== 56 || JSON.stringify(ids) !== JSON.stringify(manifest.runtime_order)) {
    errors.push("module IDs/order must be unique and equal runtime_order");
  }
  const expectedFiles = new Set(["index.ts", "shared.ts", ...ids.map((id) => \`\${id}.ts\`)]);
  const actualFiles = new Set(readdirSync(fromRoot("src", "game", "tracks")).filter((name) => name.endsWith(".ts")));
  if (JSON.stringify([...actualFiles].sort()) !== JSON.stringify([...expectedFiles].sort())) {
    errors.push("track module directory must contain exactly shared, index and 56 track files");
  }
  for (const [key, source] of [["facade", facadeSource], ["shared", sharedSource], ["index", indexSource]]) {
    const authority = manifest.source_identities[key];
    if (gitBlobSha1(source) !== authority.git_blob_sha1 || sha256(source) !== authority.sha256) {
      errors.push(\`\${key} source identity differs from manifest\`);
    }
  }
  manifest.modules.forEach((entry, index) => {
    if (entry.ordinal !== index + 1 || entry.path !== \`src/game/tracks/\${entry.id}.ts\`) {
      errors.push(\`module entry \${index + 1} path/ordinal is invalid\`);
      return;
    }
    const source = moduleSources[entry.path];
    if (typeof source !== "string") { errors.push(\`missing module source \${entry.path}\`); return; }
    if (gitBlobSha1(source) !== entry.git_blob_sha1 || sha256(source) !== entry.sha256) {
      errors.push(\`\${entry.path} identity differs from manifest\`);
    }
    hasCanonicalDefineTrackImport(source, entry.path, errors);
    const actualId = trackIdFromObjectSource(source, entry.path, errors);
    if (actualId !== entry.id) errors.push(\`\${entry.path} exports id \${actualId} instead of \${entry.id}\`);
  });
  validateIndex(indexSource, manifest, errors);
  const canonicalSource = input.canonicalSource ?? readCanonicalTrackSource();
  const legacyBlob = gitBlobSha1(canonicalSource);
  if (legacyBlob !== EXPECTED_LEGACY_GIT_BLOB_SHA1
    || legacyBlob !== manifest.legacy_reconstruction.expected_git_blob_sha1) {
    errors.push("reconstructed canonical source differs from accepted RSH-013 Git blob");
  }
  if (manifest.change_control?.["RSH-015_authorized"] !== false) errors.push("RSH-015 must remain unauthorized");
  return { errors, manifestSha256: sha256(manifestSource), legacyBlob, moduleCount: manifest.modules.length };
}
function isMainModule(moduleUrl) {
  const entry = process.argv[1];
  if (!entry) return false;
  try { return realpathSync(entry) === fileURLToPath(moduleUrl); } catch { return false; }
}
if (isMainModule(import.meta.url)) {
  const result = validateTrackModuleManifest();
  if (result.errors.length) {
    console.error("track-module-manifest fail\\n" + result.errors.map((error) => \`- \${error}\`).join("\\n"));
    process.exit(1);
  }
  console.log(\`track-module-manifest ok: \${result.moduleCount} modules; legacy blob \${result.legacyBlob}; manifest \${result.manifestSha256}\`);
}
`;
write("scripts/check-track-module-manifest.mjs", manifestValidatorSource);

const schemaWrapperSource = `#!/usr/bin/env node
import { readFileSync, realpathSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { fromRoot } from "./project-root.mjs";
import {
  EXPECTED_RSH_012_MERGE,
  validateTrackSchema as validateTrackSchemaCore,
} from "./check-track-schema-core.mjs";
import { validateTrackConsumerSourcePin } from "./check-track-consumer-source-pin.mjs";
import { validateTrackModuleManifest } from "./check-track-module-manifest.mjs";
import { validateTrackSchemaExports } from "./check-track-schema-exports.mjs";
import { validateTrackSchemaHardening } from "./check-track-schema-hardening.mjs";
import { validateTrackDefinitionClosure } from "./check-track-schema-definition-guard.mjs";
import { validateTrackDefImportAuthority } from "./check-track-schema-import-authority.mjs";
import { validateTrackMutationEdges } from "./check-track-schema-mutation-edges.mjs";
import { validateTrackMutationGuard } from "./check-track-schema-mutation-guard.mjs";
import { validateTrackDefTypeAuthority } from "./check-track-schema-type-authority.mjs";
import { validateTrackSupportPin } from "./check-track-schema-support-pin.mjs";
import { validateTrackTypeSourcePin } from "./check-track-type-source-pin.mjs";
import { readCanonicalTrackSource } from "./load-track-modules.mjs";

export { EXPECTED_RSH_012_MERGE };
function schemaForReviewedCore(schema) {
  if (!schema || typeof schema !== "object") return schema;
  const copy = structuredClone(schema);
  if (copy.runtime_definition_integrity) {
    copy.runtime_definition_integrity.support_sources = [];
    delete copy.runtime_definition_integrity.aggregate_basis;
    delete copy.runtime_definition_integrity.expected_aggregate_digest;
  }
  return copy;
}
export function validateTrackSchema(inputs) {
  const trackSource = inputs?.trackSource ?? readCanonicalTrackSource();
  const trackSchemaSource = inputs?.trackSchemaSource
    ?? readFileSync(fromRoot("src", "game", "track-schema.ts"), "utf8");
  const supportSources = inputs?.supportSources ?? {
    "src/game/math.ts": readFileSync(fromRoot("src", "game", "math.ts"), "utf8"),
  };
  const coreResult = validateTrackSchemaCore({
    ...inputs,
    trackSource,
    schema: schemaForReviewedCore(inputs?.schema),
    supportSources: {},
  });
  if (Array.isArray(coreResult)) return coreResult;
  const hardening = validateTrackSchemaHardening({
    ...inputs,
    trackSource,
    supportSources,
    trackSchemaSource,
    coreResult,
  });
  const moduleManifestResult = validateTrackModuleManifest({ canonicalSource: inputs?.trackSource ?? undefined });
  const consumerSourcePinResult = validateTrackConsumerSourcePin({ consumerSources: inputs?.consumerSources });
  const exportErrors = validateTrackSchemaExports(trackSchemaSource);
  const importAuthorityErrors = validateTrackDefImportAuthority(trackSchemaSource);
  const typeAuthorityErrors = validateTrackDefTypeAuthority(inputs?.typeSource);
  const typeSourcePinResult = validateTrackTypeSourcePin(inputs?.typeSource);
  const supportPinResult = validateTrackSupportPin({
    schema: inputs?.schema,
    supportSources,
    aggregateDigest: hardening.aggregateDigest,
  });
  const mutationErrors = validateTrackMutationGuard(trackSource);
  const mutationEdgeErrors = validateTrackMutationEdges(trackSource);
  const definitionClosureErrors = validateTrackDefinitionClosure(trackSource);
  return {
    ...coreResult,
    errors: [
      ...coreResult.errors,
      ...hardening.errors,
      ...moduleManifestResult.errors,
      ...consumerSourcePinResult.errors,
      ...exportErrors,
      ...importAuthorityErrors,
      ...typeAuthorityErrors,
      ...typeSourcePinResult.errors,
      ...supportPinResult.errors,
      ...mutationErrors,
      ...mutationEdgeErrors,
      ...definitionClosureErrors,
    ],
    aggregateDigest: hardening.aggregateDigest,
    supportSourceIdentities: hardening.supportSourceIdentities,
    mathSupportGitBlobSha1: supportPinResult.actualGitBlobSha1,
    trackConsumerSourceIdentities: consumerSourcePinResult.identities,
    trackModuleManifestSha256: moduleManifestResult.manifestSha256,
    reconstructedTrackSourceGitBlobSha1: moduleManifestResult.legacyBlob,
    trackTypeSourceGitBlobSha1: typeSourcePinResult.actualGitBlobSha1,
  };
}
function isMainModule(moduleUrl) {
  const entry = process.argv[1];
  if (!entry) return false;
  try { return realpathSync(entry) === fileURLToPath(moduleUrl); } catch { return false; }
}
if (isMainModule(import.meta.url)) {
  const schema = JSON.parse(readFileSync(fromRoot("TRACK-SCHEMA.json"), "utf8"));
  const classification = JSON.parse(readFileSync(fromRoot("TRACK-CATALOGUE-CLASSIFICATION.json"), "utf8"));
  const result = validateTrackSchema({
    schema,
    classification,
    typeSource: readFileSync(fromRoot("src", "game", "types.ts"), "utf8"),
    trackSource: readCanonicalTrackSource(),
    trackSchemaSource: readFileSync(fromRoot("src", "game", "track-schema.ts"), "utf8"),
    supportSources: { "src/game/math.ts": readFileSync(fromRoot("src", "game", "math.ts"), "utf8") },
  });
  if (Array.isArray(result) || result.errors.length) {
    const errors = Array.isArray(result) ? result : result.errors;
    console.error("track-schema fail\\n" + errors.map((error) => \`- \${error}\`).join("\\n"));
    process.exit(1);
  }
  console.log(
    \`track-schema ok: 56 modules; legacy blob \${result.reconstructedTrackSourceGitBlobSha1};\`
    + \` type blob \${result.trackTypeSourceGitBlobSha1}; 4 consumer blobs;\`
    + \` math blob \${result.mathSupportGitBlobSha1}; track digest \${result.digest};\`
    + \` aggregate \${result.aggregateDigest}; 8 MVP; 48 deferred; 0/13 gates\`,
  );
}
`;
write("scripts/check-track-schema.mjs", schemaWrapperSource);

const moduleManifestTestSource = `import assert from "node:assert/strict";
import { test } from "node:test";
import { validateTrackModuleManifest } from "./check-track-module-manifest.mjs";
import { readCanonicalTrackSource, readTrackModuleBundle } from "./load-track-modules.mjs";

test("RSH-014 commits exactly one canonical module per track", () => {
  const result = validateTrackModuleManifest();
  assert.deepEqual(result.errors, []);
  assert.equal(result.moduleCount, 56);
});

test("the modular authorities reconstruct the accepted RSH-013 source byte-for-byte", () => {
  const source = readCanonicalTrackSource();
  assert.equal(source.includes('export const TRACKS: TrackDef[] = ['), true);
  assert.equal(source.match(/^\\s{4}id:\\s*"[^"]+",$/gm)?.length, 56);
  assert.equal(validateTrackModuleManifest().legacyBlob, "${RSH013_LEGACY_BLOB}");
});

test("missing, substituted and reordered module authorities fail closed", () => {
  const baseline = readTrackModuleBundle();
  const missing = structuredClone(baseline);
  delete missing.moduleSources[missing.manifest.modules[0].path];
  assert.match(validateTrackModuleManifest({ bundle: missing }).errors.join("\\n"), /missing module source/);

  const changed = structuredClone(baseline);
  const first = changed.manifest.modules[0];
  changed.moduleSources[first.path] = changed.moduleSources[first.path].replace(
    \`id: "\${first.id}"\`,
    'id: "invalid-track-id"',
  );
  assert.match(validateTrackModuleManifest({ bundle: changed }).errors.join("\\n"), /identity differs|exports id/);

  const reordered = structuredClone(baseline);
  [reordered.manifest.modules[0], reordered.manifest.modules[1]] = [
    reordered.manifest.modules[1], reordered.manifest.modules[0],
  ];
  assert.match(validateTrackModuleManifest({ bundle: reordered }).errors.join("\\n"), /manifest differs|IDs\/order|path\/ordinal/);
});

test("RSH-015 remains unauthorized after the batch closes", () => {
  const bundle = structuredClone(readTrackModuleBundle());
  bundle.manifest.change_control["RSH-015_authorized"] = true;
  bundle.manifestSource = JSON.stringify(bundle.manifest, null, 2) + "\\n";
  assert.match(validateTrackModuleManifest({ bundle }).errors.join("\\n"), /RSH-015/);
});
`;
write("scripts/check-track-module-manifest.test.mjs", moduleManifestTestSource);

const retiredPinTestSource = `import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { test } from "node:test";
import { fromRoot } from "./project-root.mjs";
import { validateTrackModuleManifest } from "./check-track-module-manifest.mjs";

test("RSH-014 replaces the single-file source pin with the modular manifest", () => {
  assert.equal(existsSync(fromRoot("TRACK-SOURCE-PIN.json")), false);
  assert.deepEqual(validateTrackModuleManifest().errors, []);
});
`;
write("scripts/check-track-source-pin.test.mjs", retiredPinTestSource);
rmSync(abs("TRACK-SOURCE-PIN.json"), { force: true });

patchCanonicalTrackReads();

// Ensure the core validator CLI also consumes the reconstructed source.
{
  const path = "scripts/check-track-schema-core.mjs";
  let source = read(path);
  source = source.replace(
    'import { fromRoot } from "./project-root.mjs";',
    'import { fromRoot } from "./project-root.mjs";\nimport { readCanonicalTrackSource } from "./load-track-modules.mjs";',
  );
  source = source.replace(
    /const trackSource = readFileSync\(fromRoot\("src", "game", "tracks\.ts"\), "utf8"\);/,
    "const trackSource = readCanonicalTrackSource();",
  );
  write(path, source);
}

// Record the modular source authority in the machine schema without changing semantic contracts.
{
  const schema = JSON.parse(read("TRACK-SCHEMA.json"));
  schema.source_layout = {
    state: "modular",
    unit: "RSH-014",
    manifest: "TRACK-MODULE-MANIFEST.json",
    facade: "src/game/tracks.ts",
    shared: "src/game/tracks/shared.ts",
    index: "src/game/tracks/index.ts",
    module_directory: "src/game/tracks",
    module_count: 56,
    one_module_per_track: true,
    reconstructed_legacy_git_blob_sha1: RSH013_LEGACY_BLOB,
  };
  schema.semantic_invariants.one_module_per_track = true;
  schema.semantic_invariants.modular_source_manifest_pinned = true;
  schema.change_control["RSH-014_completed_on_merge"] = true;
  writeJson("TRACK-SCHEMA.json", schema);
}

function updateJsonControls() {
  const current = JSON.parse(read("CURRENT-STATE.json"));
  current.schema_version = "3.0.0";
  current.generated_at = "2026-08-29T21:30:00+03:00";
  current.state_semantics.effective_event = "merge_of_RSH_014_pull_request";
  current.state_semantics.implementation_base_sha = BASE_SHA;
  current.state_semantics.self_reference_boundary = "The RSH-014 candidate cannot contain its own future merge SHA. Exact PR, merge and post-merge CI evidence are read from live GitHub and recorded on the pull request after acceptance.";
  current.verified_main = {
    head_sha: BASE_SHA,
    tree_sha: BASE_TREE,
    commit_authored_at: "2026-08-29T21:13:24+03:00",
    commit_message: "Merge PR #16: RSH-013 — Define and validate the canonical track schema",
    commit_signature_verified: true,
    role: "RSH-014 exact implementation base",
  };
  current.program_status.accepted_units = 14;
  current.program_status.units_in_review = 0;
  current.program_status.eligible_units = 0;
  current.program_status.deferred_units = 53;
  current.program_status.remaining_units = 53;
  current.program_status.queue_head = "RSH-015";
  current.program_status.queue_head_state = "deferred_not_authorized";
  current.program_status.queue_head_branch = null;
  current.program_status.queue_head_pull_request = null;
  current.program_status.automatic_execution = false;
  current.accepted_units["RSH-013"] = {
    ...(current.accepted_units["RSH-013"] ?? {}),
    pr: 16,
    merge_sha: BASE_SHA,
    tree_sha: BASE_TREE,
    validated_head_sha: RSH013_PR_HEAD,
    workflow_run: 33267261261,
    workflow_job: 99139442443,
    post_merge_workflow_run: 33267678176,
    post_merge_workflow_job: 99140544856,
    runtime_definition_digest: RSH013_RUNTIME_DIGEST,
    state: "accepted",
  };
  current.accepted_units["RSH-014"] = {
    state: "accepted_on_merge",
    branch: "agent/rsh-014-track-modules",
    pull_request_resolution: "the pull request created from this branch",
    validated_head_resolution: "exact pull-request head accepted by required-ci / validate and Codex review",
    merge_sha_resolution: "live main HEAD created by merging the RSH-014 pull request",
    module_manifest: "TRACK-MODULE-MANIFEST.json",
    module_count: 56,
    runtime_definition_digest: RSH013_RUNTIME_DIGEST,
    aggregate_definition_digest: RSH013_AGGREGATE_DIGEST,
    runtime_data_changes: 0,
    runtime_order_changes: 0,
  };
  current.active_change = null;
  current.last_transition = {
    unit: "RSH-014",
    state: "accepted_on_merge",
    branch: "agent/rsh-014-track-modules",
    pull_request_resolution: "live GitHub pull request for this branch",
    merge_sha_resolution: "live main HEAD created by merge",
  };
  current.batch_authorization.completed_units = 5;
  current.batch_authorization.state = "closed_after_RSH-014";
  current.batch_authorization["RSH-015_authorized"] = false;
  current.validation["RSH-014_precreated"] = false;
  current.validation["RSH-014_module_count"] = 56;
  current.validation["RSH-014_runtime_data_changes"] = 0;
  current.validation["RSH-014_runtime_order_changes"] = 0;
  current.validation["RSH-015_precreated"] = false;
  current.validation["RSH-015_authorized"] = false;
  current.rsh_014_modularization = {
    state: "accepted_on_merge",
    manifest: "TRACK-MODULE-MANIFEST.json",
    modules: 56,
    legacy_blob: RSH013_LEGACY_BLOB,
    runtime_digest: RSH013_RUNTIME_DIGEST,
    aggregate_digest: RSH013_AGGREGATE_DIGEST,
    runtime_data_changes: 0,
    runtime_order_changes: 0,
  };
  writeJson("CURRENT-STATE.json", current);

  const queue = JSON.parse(read("QUEUE.json"));
  queue.schema_version = "3.0.0";
  queue.generated_at = "2026-08-29T21:30:00+03:00";
  queue.verified_base_sha = BASE_SHA;
  queue.state_effective_on = "merge_of_RSH_014_pull_request";
  queue.policy.active_bounded_batch.completed = 5;
  queue.policy.active_bounded_batch.state = "closed_after_RSH-014";
  queue.counts = { total: 67, accepted: 14, in_review: 0, eligible: 0, deferred: 53, remaining: 53 };
  queue.queue_head = {
    id: "RSH-015",
    title: "Extract the world core from world.ts",
    state: "deferred_not_authorized",
    branch: null,
    pull_request: null,
    acceptance_condition: "A new explicit owner instruction is required before RSH-015 may start.",
  };
  queue.next_after_acceptance = {
    id: "RSH-015",
    title: "Extract the world core from world.ts",
    state: "deferred_not_authorized",
  };
  queue.accepted["RSH-013"] = {
    ...(queue.accepted["RSH-013"] ?? {}),
    pull_request: 16,
    merge_sha: BASE_SHA,
    tree_sha: BASE_TREE,
    validated_head_sha: RSH013_PR_HEAD,
    workflow_run: 33267261261,
    workflow_job: 99139442443,
    post_merge_workflow_run: 33267678176,
    post_merge_workflow_job: 99140544856,
  };
  queue.accepted["RSH-014"] = {
    state: "accepted_on_merge",
    branch: "agent/rsh-014-track-modules",
    pull_request_resolution: "live GitHub pull request for this branch",
    merge_sha_resolution: "live main HEAD created by merge",
    module_manifest: "TRACK-MODULE-MANIFEST.json",
    module_count: 56,
  };
  queue.next_instruction_contract = {
    ...(queue.next_instruction_contract ?? {}),
    current_instruction: "next 2",
    authorized_sequence: ["RSH-013", "RSH-014"],
    completed_sequence: ["RSH-013", "RSH-014"],
    batch_authority_remaining: 0,
    batch_closed: true,
    "RSH-014_precreated": false,
    "RSH-015_authorized": false,
    continuation: "A new explicit owner instruction is required.",
  };
  if (queue.state_rules) {
    queue.state_rules.accepted = { from: "RSH-001", through: "RSH-014" };
    queue.state_rules.eligible = [];
    queue.state_rules.deferred = { from: "RSH-015", through: "RSH-067" };
  }
  writeJson("QUEUE.json", queue);

  const baseline = JSON.parse(read("BASELINE-REGISTER.json"));
  baseline.schema_version = "2.0.0";
  baseline.generated_at = "2026-08-29T21:30:00+03:00";
  const rsh13 = baseline.baselines.find((entry) => entry.id === "B013-rsh-013-accepted");
  if (rsh13) {
    Object.assign(rsh13, {
      kind: "accepted-unit",
      pull_request: 16,
      commit_sha: BASE_SHA,
      tree_sha: BASE_TREE,
      validated_head_sha: RSH013_PR_HEAD,
      workflow_run: 33267261261,
      workflow_job: 99139442443,
      artifact_id: 9719016086,
      artifact_digest: "sha256:9c84d5dc5829320640deb4738d0902f9c1d1f450c337011ae0bc61b7c9e2cc6c",
      post_merge_workflow_run: 33267678176,
      post_merge_workflow_job: 99140544856,
      post_merge_artifact_id: 9719170137,
      post_merge_artifact_digest: "sha256:2d573fb27dedf35ce32fedb44a8a9ee25004f91641a195e1b55ebe2facec5c3b",
      recorded_at: "2026-08-29T21:13:24+03:00",
    });
    delete rsh13.validated_head_resolution;
    delete rsh13.commit_sha_resolution;
    delete rsh13.tree_sha_resolution;
    delete rsh13.exact_evidence_reconciliation;
  }
  if (!baseline.baselines.some((entry) => entry.id === "B014-rsh-014-accepted")) {
    baseline.baselines.push({
      id: "B014-rsh-014-accepted",
      kind: "accepted-unit-on-merge",
      unit: "RSH-014",
      branch: "agent/rsh-014-track-modules",
      pull_request_resolution: "live GitHub pull request for this branch",
      validated_head_resolution: "exact pull-request head accepted by required-ci / validate and Codex review",
      commit_sha_resolution: "live main HEAD created by merging the RSH-014 pull request",
      tree_sha_resolution: "tree of the live RSH-014 merge commit",
      exact_evidence_record: "pull-request acceptance comment after merge",
      module_manifest: "TRACK-MODULE-MANIFEST.json",
      module_count: 56,
      runtime_definition_digest: RSH013_RUNTIME_DIGEST,
      recorded_at: "2026-08-29T21:30:00+03:00",
      description: "Exactly 56 track definitions relocated to one module each with byte-identical legacy reconstruction and zero runtime data/order change.",
    });
  }
  baseline.working_state = {
    unit: "RSH-014",
    state: "accepted_on_merge",
    base_commit_sha: BASE_SHA,
    branch: "agent/rsh-014-track-modules",
    pull_request_resolution: "live GitHub pull request for this branch",
    head_sha_resolution: "exact PR head accepted by required-ci / validate and Codex review",
    merge_sha_resolution: "live main HEAD created by merging the RSH-014 pull request",
    module_manifest: "TRACK-MODULE-MANIFEST.json",
    module_count: 56,
    runtime_definition_digest: RSH013_RUNTIME_DIGEST,
    is_release: false,
    tag_created: false,
    release_created: false,
    live_branch_protection: false,
    settings_application_state: "owner_action_required",
  };
  baseline.post_merge_queue = {
    queue_head: "RSH-015",
    state: "deferred_not_authorized",
    branch: null,
    pull_request: null,
    requires_new_next: true,
    "RSH-015_authorized": false,
  };
  writeJson("BASELINE-REGISTER.json", baseline);
}
updateJsonControls();

// Replace program-control tests with post-RSH-014 exact state assertions while retaining prior evidence checks.
{
  let source = read("scripts/program-control.test.mjs");
  source = source.replaceAll("merge_of_pull_request_16", "merge_of_RSH_014_pull_request");
  source = source.replace(
    'test("the owner-bounded batch has exactly four accepted units on RSH-013 merge", () => {',
    'test("the owner-bounded batch closes with five accepted units on RSH-014 merge", () => {',
  );
  source = source.replace("assert.equal(current.batch_authorization.completed_units, 4);", "assert.equal(current.batch_authorization.completed_units, 5);");
  source = source.replace("assert.equal(queue.policy.active_bounded_batch.completed, 4);", "assert.equal(queue.policy.active_bounded_batch.completed, 5);");
  source = source.replace("assert.equal(queue.next_instruction_contract.batch_authority_remaining, 1);", "assert.equal(queue.next_instruction_contract.batch_authority_remaining, 0);\n  assert.equal(queue.next_instruction_contract.batch_closed, true);");
  const start = source.indexOf('test("RSH-013 becomes accepted on merge and RSH-014 is the sole eligible final batch unit"');
  const end = source.indexOf('\ntest("asset provenance remains accepted', start);
  invariant(start >= 0 && end > start, "program-control RSH-013 test boundary not found");
  const replacement = `test("RSH-014 becomes accepted on merge and closes the bounded batch", () => {
  const current = readJson("CURRENT-STATE.json");
  const queue = readJson("QUEUE.json");
  const baseline = readJson("BASELINE-REGISTER.json");
  const schema = readJson("TRACK-SCHEMA.json");
  const modules = readJson("TRACK-MODULE-MANIFEST.json");
  assert.equal(queue.counts.accepted, 14);
  assert.equal(queue.counts.in_review, 0);
  assert.equal(queue.counts.eligible, 0);
  assert.equal(queue.counts.deferred, 53);
  assert.equal(queue.counts.remaining, 53);
  assert.equal(queue.queue_head.id, "RSH-015");
  assert.equal(queue.queue_head.state, "deferred_not_authorized");
  assert.equal(queue.queue_head.branch, null);
  assert.equal(queue.queue_head.pull_request, null);
  assert.equal(current.active_change, null);
  assert.equal(current.last_transition.unit, "RSH-014");
  assert.equal(current.last_transition.state, "accepted_on_merge");
  assert.equal(current.accepted_units["RSH-013"].merge_sha, "${BASE_SHA}");
  assert.equal(current.accepted_units["RSH-014"].state, "accepted_on_merge");
  assert.equal(current.accepted_units["RSH-014"].module_count, 56);
  assert.equal(modules.modules.length, 56);
  assert.equal(modules.semantic_integrity.runtime_data_changes, 0);
  assert.equal(modules.semantic_integrity.runtime_order_changes, 0);
  assert.equal(schema.source_layout.state, "modular");
  assert.equal(schema.runtime_definition_integrity.expected_digest, "${RSH013_RUNTIME_DIGEST}");
  assert.equal(baseline.working_state.unit, "RSH-014");
  assert.equal(baseline.working_state.state, "accepted_on_merge");
  assert.equal(queue.next_instruction_contract.batch_authority_remaining, 0);
  assert.equal(queue.next_instruction_contract["RSH-015_authorized"], false);
  assert.equal(queue.next_after_acceptance.id, "RSH-015");
  assert.equal(queue.next_after_acceptance.state, "deferred_not_authorized");
});
`;
  source = source.slice(0, start) + replacement + source.slice(end + 1);
  source = source.replace(
    'assert.equal(readJson("TRACK-SCHEMA.json").schema_version, "1.0.2");',
    'assert.equal(readJson("TRACK-SCHEMA.json").schema_version, "1.0.2");\n  assert.equal(readJson("TRACK-MODULE-MANIFEST.json").modules.length, 56);',
  );
  write("scripts/program-control.test.mjs", source);
}

function updateMarkdownControls() {
  const next = `# RUSH Israel — NEXT Contract\n\n**Version:** 3.0.0  \n**Repository:** \`talstilkol/rush-israel\`  \n**Canonical branch:** \`main\`  \n**RSH-014 implementation base:** \`${BASE_SHA}\`  \n**State effective on:** merge of the RSH-014 pull request  \n**Next unit:** \`RSH-015\` — deferred and not authorised\n\n## Authority\n\nGitHub is the sole source of truth. RSH-014 is the second and final unit authorised by the owner instruction \`next 2\`. After its validated merge, the bounded RSH-010–RSH-014 batch is closed.\n\n## RSH-014 acceptance boundary\n\n- exactly **56** files contain one track definition each;\n- each module default-exports \`defineTrack(object)\`;\n- \`src/game/tracks/index.ts\` constructs the catalogue with \`defineTracks\` in the exact accepted runtime order;\n- \`TRACK-MODULE-MANIFEST.json\` pins every module, facade, shared source and index;\n- the modular tree reconstructs the accepted RSH-013 \`tracks.ts\` Git blob \`${RSH013_LEGACY_BLOB}\` byte-for-byte;\n- ordered digest remains \`${RSH013_RUNTIME_DIGEST}\`;\n- aggregate digest remains \`${RSH013_AGGREGATE_DIGEST}\`;\n- runtime data/order, IDs, MVP mapping, assets and dependencies change by **0**;\n- exact-head required CI and Codex review must pass before merge.\n\n## Post-merge state\n\n| Metric | Value |\n|---|---:|\n| Total units | 67 |\n| Accepted | 14 |\n| In review | 0 |\n| Eligible | 0 |\n| Deferred | 53 |\n| Remaining | 53 |\n| Queue head | RSH-015 |\n| RSH-015 authorised | No |\n| Batch completed | 5/5 |\n| Release gates | 0/13 |\n| Unverified asset files | 66 |\n\nA new explicit owner instruction is required before RSH-015 may be created or executed.\n`;
  write("NEXT-CONTRACT.md", next);

  let master = read("MASTER-PLAN.md");
  master = master.replace("**Schema:** 2.9.0", "**Schema:** 3.0.0");
  master = master.replace(/\*\*RSH-013 reconciled implementation base:\*\* `[^`]+`/, `**RSH-014 implementation base:** \`${BASE_SHA}\``);
  master = master.replace("**State effective on:** merge of PR #16", "**State effective on:** merge of the RSH-014 pull request");
  master = master.replace("**Next eligible unit:** RSH-014", "**Next unit:** RSH-015 — deferred and not authorised");
  master = master.replace("| Accepted | 13 |", "| Accepted | 14 |");
  master = master.replace("| Eligible | 1 |", "| Eligible | 0 |");
  master = master.replace("| Remaining | 54 |", "| Remaining | 53 |");
  master = master.replace("| Queue head | RSH-014 |", "| Queue head | RSH-015 — deferred/not authorised |");
  master = master.replace("| Current batch completed | 4/5 |", "| Current batch completed | 5/5 — closed |");
  master = master.replace("ACTIVE — RSH-013 accepted on PR #16 merge; RSH-014 eligible", "ACTIVE — RSH-013 and RSH-014 accepted; RSH-015 deferred/not authorised");
  const boundaryStart = master.indexOf("## 9. Current execution boundary");
  if (boundaryStart >= 0) {
    master = master.slice(0, boundaryStart) + `## 9. Current execution boundary\n\nRSH-014 is accepted on merge only after exact-head CI and review. It replaces the monolithic track catalogue with exactly 56 per-track modules while preserving the exact RSH-013 legacy blob, semantic digests, runtime data/order and 8/48 classification.\n\nThe owner-bounded RSH-010–RSH-014 batch is then closed. RSH-015 is deferred and cannot start without a new explicit owner instruction.\n`;
  }
  write("MASTER-PLAN.md", master);

  const trackDoc = `# RUSH Israel — Canonical Modular Track Authority\n\n**Units:** RSH-013 schema; RSH-014 modularization  \n**Machine authorities:** \`TRACK-SCHEMA.json\`, \`TRACK-MODULE-MANIFEST.json\`  \n**Implementation base:** \`${BASE_SHA}\`  \n**Validator:** \`scripts/check-track-schema.mjs\`\n\n## Exact boundary\n\n| Metric | Value |\n|---|---:|\n| Per-track modules | 56 |\n| Unique TrackId values | 56 |\n| MVP | 8 |\n| Deferred | 48 |\n| Runtime data changes | 0 |\n| Runtime order changes | 0 |\n| Release gates | 0/13 |\n\nEvery track is defined exactly once in \`src/game/tracks/<id>.ts\` and default-exported through the canonical \`defineTrack\` helper. \`src/game/tracks/index.ts\` constructs \`TRACKS\` with \`defineTracks\` in the preserved runtime order. \`src/game/tracks.ts\` remains the stable public facade.\n\n## Integrity\n\n| Authority | Exact identity |\n|---|---|\n| Reconstructed RSH-013 source Git blob | \`${RSH013_LEGACY_BLOB}\` |\n| Ordered runtime-definition SHA-256 | \`${RSH013_RUNTIME_DIGEST}\` |\n| Aggregate SHA-256 | \`${RSH013_AGGREGATE_DIGEST}\` |\n| \`types.ts\` Git blob | \`${RSH013_TYPES_BLOB}\` |\n| \`math.ts\` Git blob | \`${RSH013_MATH_BLOB}\` |\n| \`world.ts\` Git blob | \`${RSH013_WORLD_BLOB}\` |\n\nThe manifest stores exact source identities for all 56 modules, the shared authority, the ordered index and the facade. A deterministic loader reconstructs the pre-modularization source byte-for-byte from those authorities; no duplicate runtime catalogue is stored. Existing schema, Ayalon-lock and mutation tests therefore continue to validate the same accepted data.\n\n## Change control\n\nRSH-014 may relocate definitions only. It changes no IDs, data, order, classification, assets or dependencies. RSH-015 remains unauthorised and cannot alter this authority without a new explicit owner instruction and reviewed validation.\n`;
  write("TRACK-SCHEMA.md", trackDoc);
}
updateMarkdownControls();

// Final cleanup: temporary executor is not part of the product history.
rmSync(abs("scripts/rsh014-migrate.mjs"), { force: true });
rmSync(abs(".github/workflows/rsh014-migrate.yml"), { force: true });

console.log(JSON.stringify({
  unit: "RSH-014",
  modules: 56,
  legacyBlob: gitBlobSha1(reconstructed),
  runtimeDigest: RSH013_RUNTIME_DIGEST,
  aggregateDigest: RSH013_AGGREGATE_DIGEST,
  manifestSha256,
  runtimeDataChanges: 0,
  runtimeOrderChanges: 0,
}, null, 2));
